<#
  .SYNOPSIS

  .DESCRIPTION
        Create Discovery Manger VM

	.NOTES
      Created on: 	9/18/2018
      Created by: 	Temitope Ogunfiditmi
      Filename:		Create-DiscoveryManagerVM.ps1
      Credits:		
      Requirements:	The installers executed via this script typically needs "Run As Administrator"
      Requires:      
#>
$defaultPrefix = "PROC"
$defaultHDDSize = 125GB
$defaultRAMSize = 8GB
$defaultCPUCount = 8
#$defaultGen = 2
$defaultVMSwitch = "TVSWITCH"
$defaultVMPath = "D:\VM"
$vmType = "Discovery Manager"

$defaultVMStartNum = 1
$defaultVMEndNum = 10



$vmNamePrefix = Read-Host "Please enter the prefix for the computer name[$defaultPrefix]"
$vmStartNum = Read-Host "Please enter the starting numerical postfix for the computer name[$defaultVMStartNum]"
$vmEndNum = Read-Host "Please enter the ending numerical postfix for the computer name(MAX 999)[$defaultVMEndNum]"
$vmHDDSize = Read-Host "Please enter the VM Hard Drive Size [$defaultHDDSize]"
$vmRAMSize = Read-Host "Please enter the VM RAM Size [$defaultRAMSize]"
$vmCPUCount = Read-Host "Please enter the VM CPU Count [$defaultCPUCount]"
$vmSwitch = Read-Host "Please enter the virtual switch name [$defaultVMSwitch]"
$vmPath = Read-Host "Please enter the path for the VMs[$defaultVMPath]"

if ([string]::IsNullOrEmpty($vmStartNum)){
    $vmStartNum = $defaultVMStartNum
}

if ([string]::IsNullOrEmpty($vmEndNum)){
    $vmEndNum = $defaultVMEndNum
}


if ([string]::IsNullOrEmpty($vmPath)){
    $vmPath = $defaultVMPath
}

if ([string]::IsNullOrEmpty($vmCPUCount)){
    $vmCPUCount = $defaultCPUCount
}

if ([string]::IsNullOrEmpty($vmRAMSize)){
    $vmRAMSize = $defaultRAMSize
}

if ([string]::IsNullOrEmpty($vmHDDSize)){
    $vmHDDSize = $defaultHDDSize
}

if ([string]::IsNullOrEmpty($vmSwitch)){
    $vmSwitch = $defaultVMSwitch
}

$vmGen = 2

#$vmInstallISO = "C:\Deploy\ISO\WinServer2016.iso"
Write-Host "Building "+ $vmType + " VM" -ForegroundColor Green
# Create VM
for ($currVM = $vmStartNum; $currVM -le $vmEndNum; $currVM++) {
    if ([string]::IsNullOrEmpty($vmNamePrefix)){
        $vmName = $defaultPrefix + $currVM.ToString("000")
    } else {
        $vmName = $vmNamePrefix + $currVM.ToString("000")
    }
    Write-Host "Creating VM " + $vmName -ForegroundColor Green
    $vmNewOSVHDPath = $($vmPath +"\" + $vmName + "\" + $vmName + "-OS.vhdx")
    $vmConfigPath = $($vmPath +"\" + $vmName + "\")
    New-VM -Name $vmName -MemoryStartupBytes $vmRAMSize -BootDevice VHD -NewVHDPath $vmNewOSVHDPath -Path $vmConfigPath -NewVHDSizeBytes $vmHDDSize  -Generation $vmGen -Switch $vmSwitch
    # Configure CPU
    Set-VMProcessor $vmName -Count $vmCPUCount

}
# Configure DVD Install Disk
#Add-VMDvdDrive -VMName $vmName -Path $vmInstallISO
#Set-VMFirmware -VMName $vmName -FirstBootDevice $(Get-VMDvdDrive -VMName $vmName)
#Start-VM -Name $vmName