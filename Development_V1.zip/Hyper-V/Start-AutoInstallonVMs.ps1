﻿<#
  .SYNOPSIS

  .DESCRIPTION
        Start Auto Install of OS on VMs

	.NOTES
      Created on: 	5/11/2019
      Created by: 	Temitope Ogunfiditmi
      Filename:		Create-DiscoveryManagerVM.ps1
      Credits:		
      Requirements:	The installers executed via this script typically needs "Run As Administrator"
      Requires:      
#>
$defaultPrefix = "PROC"
$vmType = "Discovery Manager"

$defaultVMStartNum = 1
$defaultVMEndNum = 10
$defaultvmInstallISO = "D:\Deploy\ISO\WinServer2016.iso"



$vmNamePrefix = Read-Host "Please enter the prefix for the computer name[$defaultPrefix]"
$vmStartNum = Read-Host "Please enter the starting numerical postfix for the computer name[$defaultVMStartNum]"
$vmEndNum = Read-Host "Please enter the ending numerical postfix for the computer name(MAX 999)[$defaultVMEndNum]"
$vmInstallISO = Read-Host "Please enter OS ISO Path [$defaultvmInstallISO]"


if ([string]::IsNullOrEmpty($vmStartNum)){
    $vmStartNum = $defaultVMStartNum
}

if ([string]::IsNullOrEmpty($vmEndNum)){
    $vmEndNum = $defaultVMEndNum
}



if ([string]::IsNullOrEmpty($vmInstallISO)){
    $vmInstallISO = $defaultvmInstallISO
}

$vmGen = 2


Write-Host "Starting VM Auto Install Process" -ForegroundColor Green
# Create VM
for ($currVM = $vmStartNum; $currVM -le $vmEndNum; $currVM++) {
    if ([string]::IsNullOrEmpty($vmNamePrefix)){
        $vmName = $defaultPrefix + $currVM.ToString("000")
    } else {
        $vmName = $vmNamePrefix + $currVM.ToString("000")
    }
    Write-Host "Auto Installing OS on " + $vmName -ForegroundColor Green
    # Configure DVD Install Disk
    Add-VMDvdDrive -VMName $vmName -Path $vmInstallISO
    Set-VMFirmware -VMName $vmName -FirstBootDevice $(Get-VMDvdDrive -VMName $vmName)
    Start-VM -Name $vmName

}




