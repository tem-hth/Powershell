<#
  .SYNOPSIS

  .DESCRIPTION
        MEDploy is the central deployment script used to access the other functions of the deployment package.

	.NOTES
      Created on: 	12/18/2018
      Created by: 	Temitope Ogunfiditmii
      Filename:		MEDeploy.ps1
      Credits:		
      Requirements:	The installers executed via this script typically needs "Run As Administrator"
      Requires:      
#>


function Show-MainMenu {
    Clear-Host
    Write-Host "  __  __ ___   ___           _     "    
    Write-Host " |  \/  | __| |   \ ___ _ __| |___ _  _ "
    Write-Host " | |\/| | _|  | |) / -_) '_ \ / _ \ || |"
    Write-Host " |_|  |_|___| |___/\___| .__/_\___/\_, |"
    Write-Host "                       |_|         |__/ "
    Write-Host "---------------------------------------------------"
    Write-Host "Mindseye Solutions Powershell Deployment Platform"
    Write-Host "---------------------------------------------------"
    Write-Host ""
    Write-Host " 1: Perform OS Configuration and Deployment Task"
    Write-Host " 2: Perform User Management Task"
    Write-Host " 3: Perform Software Package Installation Task"
    Write-Host " 4: Perform Hyper-V Deployment Task"
    Write-Host " 5: Perform Deployment Configuration XML Generation (Disabled)"
    Write-Host " q: Quit"
     
}

function Show-OSConfigMenu {
    do {
        Clear-Host
        Write-Host "---------------------------------------------------"
        Write-Host "OS Configuration and Deployment"
        Write-Host "---------------------------------------------------"
        Write-Host ""
        Write-Host " 1: Install Dell Firmware and Drivers"
        Write-Host " 2: Install Windows Updates using WSUSOffline"
        Write-Host " 3: Create Windows Installation ISO"
        Write-Host " 4: Create Network Share Folder on Local System"
        Write-Host " 5: Disable Windows Firewall"
        Write-Host " 6: Disable User Access Control(UAC)"
        Write-Host " 7: Disable Internet Explorer Enhanced Security(IESEC)"
        Write-Host " 8: Enable Remote Desktop Access on Local System"
        Write-Host " 9: Set Computer Name/Workgroup"
        Write-Host "10: Exclude Folders in Windows Defender"
        Write-Host "11: Create Network Card Team"
        Write-Host " b: Go Back"
        Write-Host " q: Quit"
        $submenuselection = Read-Host "Please make a selection"
        switch ($submenuselection) {
            '1' {
                # Install Dell Firmware
                .\OS\Install-DellFirmware.ps1
                pause
            }
            '2' {
                # Install Windows Update Support Windows 10/2016 x64
                .\OS\Download-WSUSOffline.ps1
                .\OS\Download-WindowsUpdates.ps1
                .\OS\Install-WindowsUpdates.ps1
                pause

            }
            '3' {
                # Create Windows Installation ISO
                .\OS\Create-WindowsOSISO.ps1
            }
            '4' {
                # Create Network Share Folder on Local System"
                $ShareName = Read-Host "What is the network share name"
                $ShareFolder = Read-Host "What is the folder path of the network share"
                $FullAccessUser = Read-Host "What user should have full access"
                $ReadAccessUser = Read-Host "What user should have read access"

                .\OS\Create-ShareDrive.ps1 $ShareName $ShareFolder $FullAccessUser $ReadAccessUser
            }
            '5' {
                # Disable Windows Firewall
                .\OS\Disable-Firewall.ps1
                pause
            }
            '6' {
                # Disable User Access Control(UAC)
                .\OS\Disable-UAC.ps1 
                pause

            }
            '7' {
                # Disable Internet Explorer Enhanced Security(IESEC)
                .\OS\Disable-IESec.ps1
                pause  
            }
            '8'{
                # Enable Remote Desktop Access on Local System
                .\OS\Enable-RDP.ps1
                pause
            }
            '9'{
                # Set Computer Name/Workgroup
                Rename-Computer
                Pause 
            }
            '10'{
                # Exclude Folders in Windows Defender
                .\OS\Exclude-WindowsDefenderPaths.ps1
                pause
            }
            '11'{
                # Create Network Card Team
                .\OS\Configure-TeamNic.ps1
                pause

            }
            'q' {
                exit 
            }
        }
    } until( $submenuselection -eq 'b')
}

function Show-UserManagementMenu {
    do {
        Clear-Host
        Write-Host "---------------------------------------------------"
        Write-Host "User Management"
        Write-Host "---------------------------------------------------"
        Write-Host ""
        Write-Host " 1: Create User Account on Local System"
        Write-Host " 2: Enable Remote Desktop Permissions for User Account"
        Write-Host " b: Go Back"
        Write-Host " q: Quit"
        $submenuselection = Read-Host "Please make a selection"
        switch ($submenuselection) {
            '1' {
                # Create User Account on Local System
                .\UserManagement\Create-UserAccounts.ps1
                pause
            }
            '2' {
                # Enable Remote Desktop Permissions for User Account
                .\UserManagement\Add-UserRDPAccess.ps1
                pause
            }
            
            'q' {
                exit 
            }
        }

    } until( $submenuselection -eq 'b')
}

function Show-SoftwareInstallationMenu{
    do {
        Clear-Host
        Write-Host "---------------------------------------------------"
        Write-Host "Software Installation and Configuration"
        Write-Host "---------------------------------------------------"
        Write-Host "" 
        Write-Host " 1: Install Notepad++"
        Write-Host " 2: Install Chrome"
        Write-Host " 3: Install Lotus Notes"
        Write-Host " 4: Configure Outlook"  
        Write-Host " 5: Install SQL Server Managment Studio" 
        Write-Host " 6. Install Hyper-V"
        Write-Host " 7. Install IIS"
        Write-Host " 8: Install .Net Framework 4.7"
        Write-Host " 9: Install Dell Open Manage Server Administrator"
        Write-Host " b: Go Back"
        Write-Host " q: Quit"
        $submenuselection = Read-Host "Please make a selection"
        switch ($submenuselection) {
            '1' {
                # Install Notepad++
                .\SoftwareInstallation\Install-NotepadPlusPlus.ps1
                pause
            }
            '2' {
                # Install Chrome
                .\SoftwareInstallation\Install-Chrome.ps1
                pause
            }
            '3' {
                # Install Lotus Notes
                .\SoftwareInstallation\Install-Notes9.ps1
                pause
            }
            '4' {
                 # Configure Outlook
                 .\SoftwareInstallation\Configure-Outlook.ps1
                 pause

            }
            '5' {
                # Install SQL Server Managment Studio
                .\SoftwareInstallation\Install-SMMS.ps1
                pause

            }
            '6' {
                # Install Hyper-V
                .\SoftwareInstallation\Install-HyperV.ps1
                pause
            }
            '7' {
                # Install IIS
                .\SoftwareInstallation\Install-IIS.ps1
                pause

            } 
            '8' {
                # Install .Net Framework 4.7
                .\SoftwareInstallation\Install-DotNet.ps1
                Pause
            }
            '9' {
                # Install Dell Open Manage Server Administrator
                .\SoftwareInstallation\Install-OMSA.ps1 
                Pause
            }
            'q' {
                exit 
            }
        }
    } until( $submenuselection -eq 'b')
}


function Show-HyperVDeploymentMenu {
    do {
    Clear-Host
    Write-Host "---------------------------------------------------"
    Write-Host "Hyper-V Deployment and Configuration "
    Write-Host "---------------------------------------------------"
    Write-Host ""
    Write-Host " 1: Install Hyper-V"
    Write-Host " 2: Configure Hyper-V Network Switch"
    Write-Host " 3: Create SQL Server VM"
    Write-Host " 4: Create Web Server VM"
    Write-Host " 5: Create Discovery Manager VM(s)"
    Write-Host " 6: Create Discovery Agent VM(s)" 
    Write-Host " 7: Rename Computer Name to VM Name"
    Write-Host " b: Go Back"
    Write-Host " q: Quit"
    $submenuselection = Read-Host "Please make a selection"
    switch ($submenuselection) {
        '1' {
            # Install Hyper-V
            .\SoftwareInstallation\Install-HyperV.ps1
            Pause
        }
        '2' {
            # Configure Hyper-V Network Switch
            .\Hyper-V\Configure-HyperV-VirtualSwitch.ps1
            Pause
        }
        '3' {
            # Create SQL Server VM
            .\Hyper-V\Create-SQLServerVM.ps1
            Pause
        }
        '4' {
            # Create Web Server VM
            .\Hyper-V\Create-WebServerVM.ps1
            Pause
        }
        '5' {
            # Create Discovery Manager VM 
            .\Hyper-V\Create-DiscoveryManagerVM.ps1
            Pause
        }
        '6' {
            # Create Discovery Agent VM
            .\Hyper-V\Create-DiscoveryAgentVM.ps1
            Pause
        }
        '7' {
            # Rename Computer Name to VM Name
            .\Hyper-V\Create-WebServerVM.ps1
            Pause
        }
        'q' {
            exit
        }
        
    }

    } until ($submenuselection -eq 'b')
}

# Main Selection Menu
do {
    Show-MainMenu
    $selection = Read-Host "Please make a selection"
    switch($selection)
    {
        '1'{
            Show-OSConfigMenu
        } 
        '2' {
            Show-UserManagementMenu
        }
        '3' {
            Show-SoftwareInstallationMenu
        }
        '4' {
            Show-HyperVDeploymentMenu
        }
        '5' {
            # Configuration Menu
        }
    }
    

} 
until ($selection -eq 'q')