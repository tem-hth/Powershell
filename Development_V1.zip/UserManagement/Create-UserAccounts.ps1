<#
  .SYNOPSIS

  .DESCRIPTION
        Create User Accounts

	.NOTES
      Created on: 	9/18/2018
      Created by: 	Temitope Ogunfiditmii
      Filename:		Create-UserAccounts.ps1
      Credits:		
      Requirements:	The installers executed via this script typically needs "Run As Administrator"
      Requires:      
#>

# Get command line parameter auto to determine run method - Valid values (true or false). Default to false
param([string]$auto="false") 




# Change to secure later
[Byte[]] $key = (1..16)

# Import config file
$configFilePath = ".\MES-Config.xml"
[xml]$ConfigFile = Get-Content $configFilePath

# Initialize Config Account Variables
$adminAccount
$serviceAccount
$userAccount
$adminAccountPW
$serviceAccountPW
$userAccountPW
$saveXMLConfig = "n"

# Read Account Settings from XML
if ($ConfigFile.Settings.UserAccounts.AccountAdmin){

    $adminAccount = $ConfigFile.Settings.UserAccounts.AccountAdmin
    $adminAccountPW = $ConfigFile.Settings.UserAccounts.AdminPW | ConvertTo-SecureString -Key $key
}
else {
    $adminAccount = $ConfigFile.Settings.UserAccounts.DefaultAdmin
    $adminAccountPW = $ConfigFile.Settings.UserAccounts.DefaultPW | ConvertTo-SecureString -Key $key
}

if ($ConfigFile.Settings.UserAccounts.AccountService){
    $serviceAccount = $ConfigFile.Settings.UserAccounts.AccountService
    $serviceAccountPW = $ConfigFile.Settings.UserAccounts.ServicePW | ConvertTo-SecureString -Key $key
}
else {
    $serviceAccount = $ConfigFile.Settings.UserAccounts.DefaultService
    $serviceAccountPW = $ConfigFile.Settings.UserAccounts.DefaultPW | ConvertTo-SecureString -Key $key
}

if ($ConfigFile.Settings.UserAccounts.AccountUser){
    $userAccount = $ConfigFile.Settings.UserAccounts.AccountUser
    #$userAccountPW = $ConfigFile.Settings.UserAccounts.UserPW 
    $userAccountPW = $ConfigFile.Settings.UserAccounts.UserPW | ConvertTo-SecureString -Key $key
}
else {
    $userAccount = $ConfigFile.Settings.UserAccounts.DefaultUser
    #$userAccountPW = $ConfigFile.Settings.UserAccounts.DefaultPW 
    $userAccountPW = $ConfigFile.Settings.UserAccounts.DefaultPW | ConvertTo-SecureString -Key $key
}




if ($auto -eq "false") {
    Write-Host "#### Creating three MES Accounts in Manual Mode #####" -ForegroundColor Yellow
    $selectedAdminAccount = Read-Host "Please enter the name of the admin user(default is $adminAccount)"
    $selectedAdminAccountPW = Read-Host "Please enter the password for the admin user" -AsSecureString
    $selectedServiceAccount  = Read-Host "Please enter the name of the service account(default is $serviceAccount)"
    $selectedServiceAccountPW = Read-Host "Please enter the password for the service account" -AsSecureString
    $selectedUserAccount = Read-Host "Please enter the name of the standard user(default is $userAccount)"
    $selectedUserAccountPW = Read-Host "Please enter the password for the standard user" -AsSecureString
    Write-Host "You should save user config if you will like to use the credentials for VM Creation." -ForegroundColor Yellow
    $saveXMLConfig = Read-Host "Do you want to save user config?(y/n)"
}
elseif ($auto -eq "true") {
    Write-Host "#### Creating three MES Accounts in Auto Mode #####" -ForegroundColor Yellow
} else {
    Write-Host "Invalid Mode: Options true or false" -ForegroundColor Red
    Exit
}

$DefaultPass = ConvertTo-SecureString -String "M3$@dm1n!!" -AsPlainText -Force

if (([string]::IsNullOrEmpty($selectedAdminAccount))) {
    $selectedAdminAccount = $adminAccount
    #$selectedAdminAccountPW = $adminAccountPW
    $selectedAdminAccountPW = $DefaultPass
}
if (([string]::IsNullOrEmpty($selectedServiceAccount))) {
    $selectedServiceAccount = $serviceAccount
    #$selectedServiceAccountPW = $serviceAccountPW
    $selectedServiceAccountPW = $DefaultPass
}
if (([string]::IsNullOrEmpty($selectedUserAccount))) {
    $selectedUserAccount = $userAccount
    #$selectedUserAccountPW = $userAccountPW
    $selectedUserAccountPW = $DefaultPass

}

#if ($saveXMLConfig -eq "y" -or "Y") {
#    $ConfigFile.Settings.UserAccounts.AccountUser = [string]$selectedUserAccount
#    $userPW = $selectedUserAccountPW | ConvertFrom-SecureString -Key $key
#    $ConfigFile.Settings.UserAccounts.UserPW = [string]$userPW
#    $ConfigFile.Settings.UserAccounts.AccountService = [string]$selectedServiceAccount
#    $servicePW = $selectedServiceAccountPW | ConvertFrom-SecureString -Key $key
#    $ConfigFile.Settings.UserAccounts.ServicePW = [string]$servicePW
#    $ConfigFile.Settings.UserAccounts.AccountAdmin = [string]$selectedAdminAccount
#    $adminPW = $selectedAdminAccountPW | ConvertFrom-SecureString -Key $key
#    $ConfigFile.Settings.UserAccounts.AdminPW = [string]$adminPW
#    $ConfigFile.Save($configFilePath)
#}


#Add Admin Account

try{
 $getUser = Get-LocalUser -Name $selectedAdminAccount -ErrorAction Stop
 $userExist = $getUser.Count -eq 1
 if($userExist) {
    Write-Host "$selectedAdminAccount Account Already Exist" -Foreground Green
 }
}
catch{
    Write-Host "User $selectedAdminAccount does not exist" -ForegroundColor Red
    Write-Host "Creating $selectedAdminAccount  Account" -ForegroundColor Yellow
    New-LocalUser $selectedAdminAccount -Password $selectedAdminAccountPW -FullName $selectedAdminAccount 
    Add-LocalGroupMember -Group "Administrators" -Member $selectedAdminAccount
    if((Get-LocalUser -Name $selectedAdminAccount).Count -eq 1) {
        Write-Host "$selectedAdminAccount has been created." -ForegroundColor Green
    }else {
        Write-Host "Unable to create $selectedAdminAccount" -ForegroundColor Red
    }

}

#Add Service Account
try{
    $getUser = Get-LocalUser -Name $selectedServiceAccount -ErrorAction Stop
    $userExist = $getUser.Count -eq 1 
    if($userExist) {
        Write-Host  "$selectedServiceAccount Account Already Exist" -Foreground Green
    }
}
catch{
    Write-Host "User $selectedServiceAccount does not exist" -ForegroundColor Red
    Write-Host "Creating $selectedServiceAccount  Account" -ForegroundColor Yellow
    New-LocalUser $selectedServiceAccount -Password $selectedServiceAccountPW -FullName $selectedServiceAccount 
    Add-LocalGroupMember -Group "Administrators" -Member $selectedServiceAccount
    if((Get-LocalUser -Name $selectedServiceAccount).Count -eq 1) {
        Write-Host "$selectedServiceAccount has been created." -ForegroundColor Green
    }else {
        Write-Host "Unable to create $selectedServiceAccount" -ForegroundColor Red
    }

}

#Add User Account
try{
    $getUser = Get-LocalUser -Name $selectedUserAccount -ErrorAction Stop
    $userExist = $getUser.Count -eq 1
    if($userExist) {
        Write-Host  "$selectedUserAccount Account Already Exist" -Foreground Green
    }
}
catch{
    Write-Host "User $selectedUserAccount does not exist" -ForegroundColor Red
    Write-Host "Creating $selectedUserAccount  Account" -ForegroundColor Yellow
    New-LocalUser $selectedUserAccount -Password $selectedUserAccountPW -FullName $selectedUserAccount 
    Add-LocalGroupMember -Group "Administrators" -Member $selectedUserAccount
    if((Get-LocalUser -Name $selectedUserAccount).Count -eq 1) {
        Write-Host "$selectedUserAccount has been created." -ForegroundColor Green
    }else {
        Write-Host "Unable to create $selectedUserAccount" -ForegroundColor Red
    }

}


# SIG # Begin signature block
# MIIOCgYJKoZIhvcNAQcCoIIN+zCCDfcCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUcl0p3STblYWYTzoPRoJTiAkZ
# JYagggtBMIIFWTCCBEGgAwIBAgIQHvPrkrypow2D/voZH0ZhxTANBgkqhkiG9w0B
# AQsFADB9MQswCQYDVQQGEwJHQjEbMBkGA1UECBMSR3JlYXRlciBNYW5jaGVzdGVy
# MRAwDgYDVQQHEwdTYWxmb3JkMRowGAYDVQQKExFDT01PRE8gQ0EgTGltaXRlZDEj
# MCEGA1UEAxMaQ09NT0RPIFJTQSBDb2RlIFNpZ25pbmcgQ0EwHhcNMTgxMDAyMDAw
# MDAwWhcNMTkxMDAyMjM1OTU5WjCBpzELMAkGA1UEBhMCVVMxDjAMBgNVBBEMBTIw
# MDExMR0wGwYDVQQIDBREaXN0cmljdCBvZiBDb2x1bWJpYTETMBEGA1UEBwwKV2Fz
# aGluZ3RvbjEaMBgGA1UECQwRMTAxIEtlbm5lZHkgU1QgTkUxDjAMBgNVBBIMBTIw
# MDExMRMwEQYDVQQKDApFcGlzb2YgTExDMRMwEQYDVQQDDApFcGlzb2YgTExDMIIB
# IjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnVqmEX0vuCM2zNZrzsks3T60
# fmPqUlAcacCTnl/JBYxQJfroZrVGuuKdk8IKlGeBGjNhWBXRcRJ7FVIMFIU2KCZS
# e1mFEPNNNZjrw4cJiirfDCKROHygXbgPih8pfxQGJl3wGdF+PjuOYrSUmFIgTLzq
# WDrSDa03n25g4S+gbaH9pf8LjVaS0Wm1Q+Q063kaymygLCmnnlqApjLGeV1QPA67
# B9lbyGl69qcOLsB6L8NwNAHYr7NTpOGliaFRyOjsxaYImxXDSS7RLpi1+ig6Ak79
# i9fOVfkX/GtrtvDo7lKAb/pzdZ6j9auDqssaerBfKH7+uecoqBr/CqRAHPiUlwID
# AQABo4IBqDCCAaQwHwYDVR0jBBgwFoAUKZFg/4pN+uv5pmq4z/nmS71JzhIwHQYD
# VR0OBBYEFCyN0y4HPzt4aNbqEw490H/m3qB4MA4GA1UdDwEB/wQEAwIHgDAMBgNV
# HRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMBEGCWCGSAGG+EIBAQQEAwIE
# EDBGBgNVHSAEPzA9MDsGDCsGAQQBsjEBAgEDAjArMCkGCCsGAQUFBwIBFh1odHRw
# czovL3NlY3VyZS5jb21vZG8ubmV0L0NQUzBDBgNVHR8EPDA6MDigNqA0hjJodHRw
# Oi8vY3JsLmNvbW9kb2NhLmNvbS9DT01PRE9SU0FDb2RlU2lnbmluZ0NBLmNybDB0
# BggrBgEFBQcBAQRoMGYwPgYIKwYBBQUHMAKGMmh0dHA6Ly9jcnQuY29tb2RvY2Eu
# Y29tL0NPTU9ET1JTQUNvZGVTaWduaW5nQ0EuY3J0MCQGCCsGAQUFBzABhhhodHRw
# Oi8vb2NzcC5jb21vZG9jYS5jb20wGQYDVR0RBBIwEIEOdGVtQGVwaXNvZi5jb20w
# DQYJKoZIhvcNAQELBQADggEBAHeDSZCt98BR+s4hW78rf9EpMghiEGVsy8CqFS7N
# n5KDXL2eefh6CHEzYPiHywCnDdUbVTrH4fnf+nvXaKP5nGCGpq68ELaWYtzjAWKY
# TFN4nwhYDjJq+Nye0XNfUf8I0+8sMurFZ6hz3BK0TvcOZRoa+ld5xRUvVXqyKYHB
# 0q+1DvCebW6VxLDPrkFHnHAhKNaKA0+K3C5R5jdAyzuGe/Qo7l9NRU/cxvmMzeEw
# n8b76kIoliEAN8BQ6BdB9vfg7TZ6yQKR6BUvNOPWLD39duFLSs1dZqSVO+cgdNNq
# n6/uJm3EdyS2iFUj2zFyAaYSnAF1u5//K9LOFKjGwAaIQ6gwggXgMIIDyKADAgEC
# AhAufIfMDpNKUv6U/Ry3zTSvMA0GCSqGSIb3DQEBDAUAMIGFMQswCQYDVQQGEwJH
# QjEbMBkGA1UECBMSR3JlYXRlciBNYW5jaGVzdGVyMRAwDgYDVQQHEwdTYWxmb3Jk
# MRowGAYDVQQKExFDT01PRE8gQ0EgTGltaXRlZDErMCkGA1UEAxMiQ09NT0RPIFJT
# QSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTAeFw0xMzA1MDkwMDAwMDBaFw0yODA1
# MDgyMzU5NTlaMH0xCzAJBgNVBAYTAkdCMRswGQYDVQQIExJHcmVhdGVyIE1hbmNo
# ZXN0ZXIxEDAOBgNVBAcTB1NhbGZvcmQxGjAYBgNVBAoTEUNPTU9ETyBDQSBMaW1p
# dGVkMSMwIQYDVQQDExpDT01PRE8gUlNBIENvZGUgU2lnbmluZyBDQTCCASIwDQYJ
# KoZIhvcNAQEBBQADggEPADCCAQoCggEBAKaYkGN3kTR/itHd6WcxEevMHv0xHbO5
# Ylc/k7xb458eJDIRJ2u8UZGnz56eJbNfgagYDx0eIDAO+2F7hgmz4/2iaJ0cLJ2/
# cuPkdaDlNSOOyYruGgxkx9hCoXu1UgNLOrCOI0tLY+AilDd71XmQChQYUSzm/sES
# 8Bw/YWEKjKLc9sMwqs0oGHVIwXlaCM27jFWM99R2kDozRlBzmFz0hUprD4DdXta9
# /akvwCX1+XjXjV8QwkRVPJA8MUbLcK4HqQrjr8EBb5AaI+JfONvGCF1Hs4NB8C4A
# NxS5Eqp5klLNhw972GIppH4wvRu1jHK0SPLj6CH5XkxieYsCBp9/1QsCAwEAAaOC
# AVEwggFNMB8GA1UdIwQYMBaAFLuvfgI9+qbxPISOre44mOzZMjLUMB0GA1UdDgQW
# BBQpkWD/ik366/mmarjP+eZLvUnOEjAOBgNVHQ8BAf8EBAMCAYYwEgYDVR0TAQH/
# BAgwBgEB/wIBADATBgNVHSUEDDAKBggrBgEFBQcDAzARBgNVHSAECjAIMAYGBFUd
# IAAwTAYDVR0fBEUwQzBBoD+gPYY7aHR0cDovL2NybC5jb21vZG9jYS5jb20vQ09N
# T0RPUlNBQ2VydGlmaWNhdGlvbkF1dGhvcml0eS5jcmwwcQYIKwYBBQUHAQEEZTBj
# MDsGCCsGAQUFBzAChi9odHRwOi8vY3J0LmNvbW9kb2NhLmNvbS9DT01PRE9SU0FB
# ZGRUcnVzdENBLmNydDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuY29tb2RvY2Eu
# Y29tMA0GCSqGSIb3DQEBDAUAA4ICAQACPwI5w+74yjuJ3gxtTbHxTpJPr8I4LATM
# xWMRqwljr6ui1wI/zG8Zwz3WGgiU/yXYqYinKxAa4JuxByIaURw61OHpCb/mJHSv
# HnsWMW4j71RRLVIC4nUIBUzxt1HhUQDGh/Zs7hBEdldq8d9YayGqSdR8N069/7Z1
# VEAYNldnEc1PAuT+89r8dRfb7Lf3ZQkjSR9DV4PqfiB3YchN8rtlTaj3hUUHr3pp
# J2WQKUCL33s6UTmMqB9wea1tQiCizwxsA4xMzXMHlOdajjoEuqKhfB/LYzoVp9QV
# G6dSRzKp9L9kR9GqH1NOMjBzwm+3eIKdXP9Gu2siHYgL+BuqNKb8jPXdf2WMjDFX
# MdA27Eehz8uLqO8cGFjFBnfKS5tRr0wISnqP4qNS4o6OzCbkstjlOMKo7caBnDVr
# qVhhSgqXtEtCtlWdvpnncG1Z+G0qDH8ZYF8MmohsMKxSCZAWG/8rndvQIMqJ6ih+
# Mo4Z33tIMx7XZfiuyfiDFJN2fWTQjs6+NX3/cjFNn569HmwvqI8MBlD7jCezdsn0
# 5tfDNOKMhyGGYf6/VXThIXcDCmhsu+TJqebPWSXrfOxFDnlmaOgizbjvmIVNlhE8
# CYrQf7woKBP7aspUjZJczcJlmAaezkhb1LU3k0ZBfAfdz/pD77pnYf99SeC7MH1c
# gOPmFjlLpzGCAjMwggIvAgEBMIGRMH0xCzAJBgNVBAYTAkdCMRswGQYDVQQIExJH
# cmVhdGVyIE1hbmNoZXN0ZXIxEDAOBgNVBAcTB1NhbGZvcmQxGjAYBgNVBAoTEUNP
# TU9ETyBDQSBMaW1pdGVkMSMwIQYDVQQDExpDT01PRE8gUlNBIENvZGUgU2lnbmlu
# ZyBDQQIQHvPrkrypow2D/voZH0ZhxTAJBgUrDgMCGgUAoHgwGAYKKwYBBAGCNwIB
# DDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEE
# AYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQU82jZwLHcomOP
# hN4mvtL4kNHrL2QwDQYJKoZIhvcNAQEBBQAEggEAKvyDF12cKXm84Vy3QyKcjMnj
# Nn0AKrCSXp3nbVweG765ZuYk2H9jmywKSchyY/hpZdiMoNVZVX761KCF8oAbv15o
# GIMO6o9m/1piaGqbb6kOmanN+BuqvAFrKFBKEICfuxqZrIZkkkAt3TzJRrU38N3c
# OQ68OsumQYyikgIMrzDeuPiKqB7gF6UhXvzgcI/rEYubsu7HCLwFxxDMhWu3y+BF
# xfzNGYhyid54tiexbIo+NkxCqbMrtSpIYiWTRM2QTvHvSAdfBXJcHSxVbmzAirNf
# U9LP6CDS+fdmhfj2xxtnIijUTjuR/YIKokhlk3AAI4DMUlzto7etg7N0V85zow==
# SIG # End signature block
